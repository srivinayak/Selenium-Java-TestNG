package org.iirdm.pf;

import org.iirdm.base.ActionsDriver;
import org.iirdm.base.ExtentTestManager;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class PrintedDress {

    WebDriver driver;

    public PrintedDress(WebDriver driver)
    {
        this.driver = driver;
        this.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "(//a[contains(text(), 'Printed Chiffon Dress')])[1]")
    WebElement PrintedChiffonDress0;

    @FindBy(xpath = "(//*[@Class = 'icon-eye-open'])[0]")
    WebElement EyeIcon0;

    @FindBy(xpath = "(//*[@id='our_price_display'])[0]")
    WebElement DisplayedPrice0;

    @FindBy(xpath = "(//span[@Class='price product-price'])[0]")
    WebElement ProductPrice0;

    public WebDriver ClickOnEyeIcon() throws InterruptedException {
        String strPath = "//*[@Class = 'icon-eye-open']";
        List<WebElement> xElements = this.driver.findElements(By.xpath(strPath));
        WebElement EyeIcon = xElements.get(0);
        //this.driver = new ActionsDriver().MoveToWebElementByAction(this.driver, EyeIcon);
        this.driver = new ActionsDriver().MoveToWebElementByLocation(this.driver, EyeIcon);
        WebDriverWait wait = new WebDriverWait(this.driver, 30);
        wait.until(ExpectedConditions.elementToBeClickable(EyeIcon));

        if(EyeIcon.isEnabled())
        {
            Thread.sleep(10000);
            //this.driver = new ActionsDriver().MoveToWebElementByLocationAndDoubleClick(this.driver, EyeIcon);
            EyeIcon.click();
            return this.driver;
        }
        else
        {
            throw new ElementNotVisibleException("Eye Icon is not Visible");
        }
    }

    public WebDriver AccessPrintedChiffonDress()
    {
        String strPath = "//a[contains(text(), 'Printed Chiffon Dress')]";
        List<WebElement> xElements = this.driver.findElements(By.xpath(strPath));
        WebElement PrintedChiffonDress = xElements.get(1);
        this.driver = new ActionsDriver().MoveToWebElementByAction(this.driver, PrintedChiffonDress);
        if(PrintedChiffonDress.isDisplayed())
        {
            return this.driver;
        }
        else
        {
            throw new ElementNotVisibleException("Printed Chiffon Element Not Visible");
            //return this.driver;
        }

    }

    //Important Method
    public WebDriver CheckTheDisplayedPrice(String ExpectedPriceData)
    {
        String strPath = "//*[@id='our_price_display']";
        List<WebElement> xElements = this.driver.findElements(By.xpath(strPath));
        WebElement DisplayedPrice = xElements.get(0);
        this.driver = new ActionsDriver().MoveToWebElementByAction(this.driver, DisplayedPrice);
        if(DisplayedPrice.isDisplayed())
        {
            String DisplayedPriceData = DisplayedPrice.getAttribute("outerText").trim();
            if(DisplayedPriceData.equals(ExpectedPriceData.trim()))
            {
                ExtentTestManager.getTest().pass("Expected Price matches Displayed Price");
            }
            else
            {
                ExtentTestManager.getTest().fail("Expected Price DoesNot Match Displayed Price");
            }
            return this.driver;
        }
        else
        {
            throw new ElementNotVisibleException("Displayed Price Object is not Visible");
        }

    }

    //Alternate Method
    public WebDriver CheckTheProductPrice(String ExpectedProductPriceData)
    {
        String strPath = "//span[@Class='price product-price']";
        List<WebElement> xElements = this.driver.findElements(By.xpath(strPath));
        WebElement ProductPrice = xElements.get(0);
        this.driver = new ActionsDriver().MoveToWebElementByAction(this.driver, ProductPrice);
        if(ProductPrice.isDisplayed())
        {
            //String ProductPriceData = ProductPrice.getCssValue("innerText");
            String ProductPriceData = ProductPrice.getCssValue("innerText");
            if(ProductPriceData.equals(ExpectedProductPriceData.trim()))
            {
                ExtentTestManager.getTest().pass("Expected Price matches Product Price");
            }
            else
            {
                ExtentTestManager.getTest().fail("Expected Price DoesNot Match Product Price");
            }
            return this.driver;
        }
        else
        {
            throw new ElementNotVisibleException("Product Price Object is not Visible");
        }

    }

    public WebDriver ClickOnPrintedChiffonDress()
    {
        String strPath = "//a[contains(text(), 'Printed Chiffon Dress')]";
        List<WebElement> xElements = this.driver.findElements(By.xpath(strPath));
        WebElement PrintedChiffonDress = xElements.get(1);
        this.driver = new ActionsDriver().MoveToWebElementByAction(this.driver, PrintedChiffonDress);
        if(PrintedChiffonDress.isEnabled())
        {
            PrintedChiffonDress.click();
            return this.driver;
        }
        else
        {
            throw new ElementNotVisibleException("Printed Chiffon Dress Element Not Enabled");
            //return this.driver;
        }

    }

    //Alternate Verification for PrintedChiffonDressPrice
    public WebDriver CheckPrintedChiffonDressPrice(String PrintedChiffonDressPrice)
    {
        String xPathSet = "//*[(@id='our_price_display') and contains(text(), '" + PrintedChiffonDressPrice + "')]";
        List<WebElement> xElements = this.driver.findElements(By.xpath(xPathSet));
        WebElement DisplayedPrintedChiffonDressPrice = xElements.get(0);

        this.driver = new ActionsDriver().MoveToWebElementByAction(this.driver, DisplayedPrintedChiffonDressPrice);
        if(DisplayedPrintedChiffonDressPrice.isDisplayed())
        {
            DisplayedPrintedChiffonDressPrice.click();
            return this.driver;
        }
        else
        {
            throw new ElementNotVisibleException("Printed Chiffon Dress Price Element Not Visible");
            //return this.driver;
        }

    }




}
