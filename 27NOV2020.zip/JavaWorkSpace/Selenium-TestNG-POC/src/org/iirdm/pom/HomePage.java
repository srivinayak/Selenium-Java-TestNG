package org.iirdm.pom;

import org.iirdm.base.ActionsDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class HomePage {

    WebDriver driver;

    String AppURL= "http://automationpractice.com/index.php";

    public HomePage(WebDriver driver)
    {
        this.driver = driver;
        this.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }


    By BestSellers1 = By.xpath("//*[@class = 'blockbestsellers'][0]");

    public WebDriver NavigateToHomePage()
    {
        this.driver.navigate().to(AppURL);
        return this.driver;
    }

    public WebDriver ClickOnBestSellers()
    {
        String strPath = "//*[@class = 'blockbestsellers']";
        List<WebElement> xElements = this.driver.findElements(By.xpath(strPath));
        WebElement BestSellers = xElements.get(0);
        this.driver = new ActionsDriver().MoveToWebElementByAction(this.driver, BestSellers);
        //String strBestSellers = BestSellers.getAttribute("innerText").trim();
        //Assert.assertEquals("Best Sellers", strBestSellers);
        BestSellers.click();
        return this.driver;
    }
}
