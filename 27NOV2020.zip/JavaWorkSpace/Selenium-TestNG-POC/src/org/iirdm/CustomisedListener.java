package org.iirdm;

import org.testng.*;
import org.testng.xml.XmlSuite;

import java.util.List;

public class CustomisedListener implements org.testng.ITestListener
{

    org.testng.Reporter LOGGER;

    @Override
    public void onTestStart(ITestResult iTestResult) {

    }

    @Override
    public void onTestSuccess(ITestResult iTestResult) {

    }

    @Override
    public void onTestFailure(ITestResult iTestResult) {

    }

    @Override
    public void onTestSkipped(ITestResult iTestResult) {

    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult iTestResult) {

    }

    @Override
    public void onStart(ITestContext iTestContext) {

    }

    @Override
    public void onFinish(ITestContext testContext) {
            LOGGER.log("PASSED TEST CASES");
            testContext.getPassedTests().getAllResults()
                    .forEach(result -> {LOGGER.log(result.getName());});

            LOGGER.log("FAILED TEST CASES");
            testContext.getFailedTests().getAllResults()
                    .forEach(result -> {LOGGER.log(result.getName());});

            LOGGER.log(
                    "Test completed on: " + testContext.getEndDate().toString());
        }

}
