package org.iirdm.test001;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.iirdm.base.*;
import org.iirdm.pom.HomePage;
import org.iirdm.utils.MyBrowser;
import org.jsoup.nodes.Element;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.IAssert;
import sun.misc.Signal;

import java.io.IOException;

public class MyTest001 {

    WebDriver driver;
    //ExtentReports extent;
    //ExtentTestManager extentTestManager;
    String testname = "Firefox-TestNG-Test";

    //@BeforeClass()
    @BeforeTest
    void myBeforeClass()
    {
        //System.out.println("BeforeClass of MyTest000");
        this.driver = new MyBrowser().SetMyBrowser("firefox");
        //this.extent = new ExtentReports(".\\test-output\\ExtentReportTestNG.html");
        //this.extent = MyTestSuite.extent;
    }

    @Test(groups = "firefox test", priority = 0)
    void testing_MyTest001()
    {
        boolean myflag;

        try {
            myflag = false;
            this.driver = new HomePage(this.driver).NavigateToHomePage();
            assert(false);
        }
        catch(AssertionError e) {

            myflag = true;
        }

        try
        {
            ExtentTestManager.getTest().fail("Firefox TestNG Test Failed");
            throw new ElementNotVisibleException("failed");
        }
        catch(Exception e)
        {
            myflag = true;
            e.printStackTrace();
        }

        if(myflag) {
            try {
                new CreateFileStampForFailedTest().MyFileStampSetter(testname);
                CreateFailedImage.CreateNewScreenShot(this.driver, this.testname);
                AppendFailedTestScreenShot.addTestFailurePNG(this.testname);
                ExtentTestManager.getTest().log(Status.FAIL, this.testname + " Failed");

            } catch (Exception e) {
            }
        }
    }


    //@AfterClass()
    @AfterTest
    void myAfterClass() throws InterruptedException {
        Thread.sleep(5000);
        //this.driver.close();
        this.driver.quit();
        //extent.endTest(this.test);
        //this.extent.flush();
        //this.extent.close();
    }
}
