package org.iirdm.base;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class ActionsDriver {

    public WebDriver MoveToWebElementByAction(WebDriver driver, WebElement xElement)
    {
        Actions actions = new Actions(driver);
        actions.moveToElement(xElement).build().perform();
        return driver;
    }

    public WebDriver MoveToWebElementByLocation(WebDriver driver, WebElement xElement)
    {
        Actions actions = new Actions(driver);
        actions.moveToElement(xElement).build().perform();

        int myX = xElement.getLocation().getX();
        int myY = xElement.getLocation().getY();

        actions.moveToElement(xElement, myX, myY).perform();

        return driver;
    }


    //Alternate JavaScript Method Using JS
    public WebDriver MoveToWebElementByLocationAndDoubleClick(WebDriver driver, WebElement xElement)
    {

        String jsDoubleClick =
                        "var target = arguments[0];                                 " +
                        "var offsetX = arguments[1];                                " +
                        "var offsetY = arguments[2];                                " +
                        "var rect = target.getBoundingClientRect();                 " +
                        "var cx = rect.left + (offsetX || (rect.width / 2));        " +
                        "var cy = rect.top + (offsetY || (rect.height / 2));        " +
                        "                                                           " +
                        "emit('mousedown', {clientX: cx, clientY: cy, buttons: 1}); " +
                        "emit('mouseup',   {clientX: cx, clientY: cy});             " +
                        "emit('mousedown', {clientX: cx, clientY: cy, buttons: 1}); " +
                        "emit('mouseup',   {clientX: cx, clientY: cy});             " +
                        "emit('click',     {clientX: cx, clientY: cy, detail: 2});  " +
                        "                                                           " +
                        "function emit(name, init) {                                " +
                        "target.dispatchEvent(new MouseEvent(name, init));          " +
                        "}                                                          " ;

        Actions actions = new Actions(driver);
        actions.moveToElement(xElement).build().perform();

        int myX = xElement.getLocation().getX();
        int myY = xElement.getLocation().getY();

        actions.moveToElement(xElement, myX, myY).perform();
        ((JavascriptExecutor)driver).executeScript(jsDoubleClick, xElement, myX, myY);
        return driver;
    }



}
