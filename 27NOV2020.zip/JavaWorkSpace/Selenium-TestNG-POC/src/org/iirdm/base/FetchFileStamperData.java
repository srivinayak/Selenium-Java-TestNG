package org.iirdm.base;

import java.io.BufferedReader;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FetchFileStamperData {

    public static String FetchData()
    {
        String data = "";
        try
        {
            data = "";
            //String fpath = System.getProperty("user.dir") + "\\" + "TestReport" + "\\" + "dat.log";
            String fpath = "TestReport" + "\\" + "dat.log";
            Path path = Paths.get(fpath);

            BufferedReader reader = Files.newBufferedReader(path);
            data = reader.readLine();

            reader.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        return data;
    }
}
