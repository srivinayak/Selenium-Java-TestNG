package org.iirdm.base;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import org.apache.commons.io.FileUtils;
import org.iirdm.utils.MyTakeScreenShot;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestResult;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.sql.Timestamp;

public class CreateFileStampForFailedTest {

    public String onTestFailure(ITestResult result){

        //String targetLocation = null;
        Timestamp sqltimestamp = new Timestamp(System.currentTimeMillis());
        String testClassName = result.getTestClass().getName().trim();

        String timeStamp = sqltimestamp.toString();

        String testMethodName = result.getName().trim();
        String screenShotName0 = testMethodName + timeStamp;

        String screenShotName1 = screenShotName0.replaceAll("-", "");
        String screenShotName2 = screenShotName1.replaceAll(":", "-");
        String screenShotName3 = screenShotName2.replaceAll(".", "");

        String screenShotName = screenShotName3 + ".png";
        return screenShotName;
    }


    public void MyFileStamper(ITestResult result)
    {
        try
        {

            String fpath = System.getProperty("user.dir") + "\\" + "TestReport" + "\\" + "dat.log";
            Writer DataWriter = new FileWriter(fpath, false);
            String fileData = onTestFailure(result);
            DataWriter.write("failed.png");
            DataWriter.flush();
            DataWriter.close();

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public void MyFileStampSetter(String testname)
    {
        try
        {

            //String fpath = "TestReport" + "\\" + "dat.log";
            String fpath = System.getProperty("user.dir") + "\\" + "TestReport" + "\\" + "dat.log";
            Writer DataWriter = new FileWriter(fpath, false);
            String fileData = "screenshots\\" + testname + ".png";
            DataWriter.write(fileData);
            DataWriter.flush();
            DataWriter.close();
            Thread.sleep(1000);

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }



}
