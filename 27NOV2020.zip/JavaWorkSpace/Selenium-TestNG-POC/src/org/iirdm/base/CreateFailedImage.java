package org.iirdm.base;
import org.openqa.selenium.WebDriver;
import org.iirdm.utils.MyTakeScreenShot;

public class CreateFailedImage {

    public static void CreateScreenShot(WebDriver driver)
    {
        try
        {

            String data = FetchFileStamperData.FetchData();
            MyTakeScreenShot.capture(driver, data);
            Thread.sleep(1000);
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }


    public static void CreateNewScreenShot(WebDriver driver, String testname)
    {
        try
        {

            String data = "TestReport\\screenshots\\" + testname + ".png";
            MyTakeScreenShot.capture(driver, data);
            Thread.sleep(1000);
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }



}
