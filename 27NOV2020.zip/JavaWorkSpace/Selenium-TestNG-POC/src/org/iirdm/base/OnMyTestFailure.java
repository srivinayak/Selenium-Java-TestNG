package org.iirdm.base;

import com.aventstack.extentreports.MediaEntityBuilder;
import org.apache.commons.io.FileUtils;
import org.iirdm.utils.MyTakeScreenShot;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.io.FileHandler;
import org.testng.ITestResult;
import org.testng.ITestContext;
//import org.testng.ITestListener;

import com.aventstack.extentreports.Status;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Timestamp;


public class OnMyTestFailure {

    public static WebDriver driver;
    //public static ITestResult myresult;

    public static void onTestFailure(ITestResult result) {
        //result = myresult;
        ExtentTestManager.getTest().log(Status.FAIL, "*** Test execution " + result.getMethod().getMethodName() + " failed...");
        ExtentTestManager.getTest().log(Status.INFO, result.getMethod().getMethodName() + " failed!");

        //ITestContext context = result.getTestContext();
        //WebDriver driver = (WebDriver) context.getAttribute("driver");

        String targetLocation;
        targetLocation = null;
        Timestamp sqltimestamp = new Timestamp(System.currentTimeMillis());
        String testClassName = result.getTestClass().getName().trim();

        try {
            MyTakeScreenShot.capture(driver, "hai.png");
        } catch (IOException e) {
            e.printStackTrace();
        }
        String timeStamp =  sqltimestamp.toString();
        //Util.getCurrentTimeStamp(); // get timestamp
        String testMethodName = result.getName().toString().trim();
        System.out.println("testMethodName = " + testMethodName);
        String screenShotName = testMethodName + timeStamp;
        String scr[] = screenShotName.split(":");
        int len = scr.length;
        String screenShotName1 = "";
        for(int i = 0; i < len; i++)
        {
            screenShotName1 = screenShotName1 + scr[i];
        }

        screenShotName = screenShotName1.trim();

        String ncr[] = screenShotName.split(".");
        len = ncr.length;

        String screenShotName2 = "";
        for(int j = 0; j < len; j++)
        {
            screenShotName2 = screenShotName2 + ncr[j];
        }
        screenShotName2 = screenShotName2 + ".png";

        screenShotName = screenShotName2.trim();

        ExtentTestManager.getTest().log(Status.INFO, screenShotName);
        String fileSeperator = "\\";
        //String fileSeperator = System.getProperty("file.separator");
        String reportsPath = System.getProperty("user.dir") + fileSeperator + "TestReport" + fileSeperator
                + "screenshots";
        ExtentTestManager.getTest().log(Status.INFO, "Screen shots reports path - " + reportsPath);
        try {
            File file = new File(reportsPath + fileSeperator + testClassName); // Set
            // screenshots
            // folder
            if (!file.exists()) {
                if (file.mkdirs()) {
                    ExtentTestManager.getTest().log(Status.INFO, "Directory: " + file.getAbsolutePath() + " is created!");
                } else {
                    ExtentTestManager.getTest().log(Status.INFO,"Failed to create directory: " + file.getAbsolutePath());
                }

            }
            if(driver.equals(null))
                System.out.println("Driver is null");
            try{

            File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            targetLocation = (reportsPath + fileSeperator + testClassName + fileSeperator + screenShotName).toString();// define
            System.out.println("targetLocation = " + targetLocation.toString());
            // location
            File targetFile = new File(targetLocation);
            FileUtils.copyFile(screenshotFile, targetFile);
            ExtentTestManager.getTest().log(Status.INFO, "Screen shot file location - " + screenshotFile.getAbsolutePath());
            ExtentTestManager.getTest().log(Status.INFO, "Target File location - " + targetFile.getAbsolutePath());
            //FileHandler.copy(screenshotFile, targetFile);
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        //} catch (FileNotFoundException e) {
        //    ExtentTestManager.getTest().log(Status.INFO, "File not found exception occurred while taking screenshot " + e.getMessage());
        } catch (Exception e) {
            ExtentTestManager.getTest().log(Status.INFO,"An exception occurred while taking screenshot " + e.getCause());
        }

        // attach screenshots to report
        try {
            ExtentTestManager.getTest().fail("Screenshot",
                    MediaEntityBuilder.createScreenCaptureFromPath(targetLocation).build());
        } catch (Exception e) {
            ExtentTestManager.getTest().log(Status.INFO, "An exception occured while taking screenshot " + e.getCause());
        }
        ExtentTestManager.getTest().log(Status.FAIL, "Test Failed");
    }

}
