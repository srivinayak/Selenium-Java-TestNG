package org.iirdm.base;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.MediaEntityModelProvider;
import com.aventstack.extentreports.Status;
import org.apache.commons.io.FileUtils;
import org.iirdm.utils.MyTakeScreenShot;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;


public class AppendPassedTestScreenShot {

    public static void addTestPassPNG(String testname) {
        try {

            //String targetLocation = FetchFileStamperData.FetchData();
            String targetLocation = "screenshots\\" + testname + ".png";

            //ExtentTestManager.getTest().fail("Screenshot", MediaEntityBuilder.createScreenCaptureFromPath(targetLocation).build());
            MediaEntityModelProvider m1 = MediaEntityBuilder.createScreenCaptureFromPath(targetLocation).build();
            ExtentTestManager.getTest().log(Status.PASS, "ScreenShot", m1);
        } catch (Exception e) {
            ExtentTestManager.getTest().log(Status.INFO, "An exception occured while taking screenshot " + e.getCause());
            ExtentTestManager.getTest().log(Status.PASS, "Test Failed");

        }
    }


}
