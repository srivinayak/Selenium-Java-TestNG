package org.iirdm.test002;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

public class MyTest002 {

    @BeforeClass()
    void myBeforeClass()
    {
        System.out.println("BeforeClass of MyTest002");
    }

    @Test(groups = "normal test", priority = 0)
    void testing_MyTest002()
    {
        System.out.println("Testing MyTest002");
    }

    @AfterClass()
    void myAfterClass()
    {
        System.out.println("AfterClass of MyTest002");
    }


}
