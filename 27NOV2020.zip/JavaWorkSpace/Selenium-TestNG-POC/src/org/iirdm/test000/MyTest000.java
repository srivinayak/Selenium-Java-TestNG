package org.iirdm.test000;

import com.aventstack.extentreports.Status;
import org.iirdm.base.*;
import org.iirdm.pf.PrintedDress;
import org.iirdm.pom.HomePage;
import org.iirdm.utils.MyBrowser;
import org.iirdm.utils.MyExcelReader;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;

public class MyTest000 {

    WebDriver driver;
    //ExtentReports extent;
    //ExtentTestManager extentTestManager;
    String testname = "GoogleChrome-TestNG-Test";

    @DataProvider(name = "test000-data-provider")
    public Object[][] MyTest000Data()
    {
        String exlPath = "src\\org\\iirdm\\testdata\\test000data.xlsx";
        MyExcelReader test000datafile = new MyExcelReader(exlPath);
        int rows = test000datafile.getRowCount(0);
        Object[][] test000data = new Object[rows][2];

        for(int i = 1 ; i < rows; i++)
        {
            test000data[i][0] = test000datafile.getData(0, i, 0);
            test000data[i][1] = test000datafile.getData(0, i, 1);
        }
        return test000data;
    }


    //@BeforeClass()
    @BeforeTest
    void myBeforeClass()
    {
        //System.out.println("BeforeClass of MyTest000");
        this.driver = new MyBrowser().SetMyBrowser("Chrome");
        //this.extent = new ExtentReports(".\\test-output\\ExtentReportTestNG.html");
        //this.extent = MyTestSuite.extent;
    }

    void testing_MyTest000_Navigate_To_HomePage()
    {
        try
        {
            this.driver = new HomePage(this.driver).NavigateToHomePage();
            //ExtentTestManager.getTest().log(Status.PASS, testname +" Passed");
        }
        catch(Exception e)
        {
            new CreateFileStampForFailedTest().MyFileStampSetter(testname);
            CreateFailedImage.CreateScreenShot(this.driver);
            AppendFailedTestScreenShot.addTestFailurePNG(testname);
            ExtentTestManager.getTest().log(Status.FAIL, testname +" Failed");
        }
    }

    void testing_MyTest000_Click_On_BestSellers()
    {
        try
        {
            this.driver = new HomePage(this.driver).ClickOnBestSellers();
        }
        catch(Exception e)
        {

        }
    }

    void testing_MyTest000_GoTo_PrintedChiffonDress()
    {
        try
        {
            this.driver = new PrintedDress(this.driver).AccessPrintedChiffonDress();
        }
        catch(Exception e)
        {

        }
    }

    void testing_MyTest000_ClickOn_EyeIcon()
    {
        try
        {
            this.driver = new PrintedDress(this.driver).ClickOnEyeIcon();
        }
        catch(Exception e)
        {

        }
    }

    void testing_MyTest000_Check_Displayed_Price(String ExpectedPriceData)
    {
        try
        {
            this.driver = new PrintedDress(this.driver).CheckTheDisplayedPrice(ExpectedPriceData);
        }
        catch(Exception e)
        {
            ExtentTestManager.getTest().fail("Expected Price does not Match Displayed Price");
            new CreateFileStampForFailedTest().MyFileStampSetter(testname);
            CreateFailedImage.CreateNewScreenShot(this.driver, this.testname);
            AppendFailedTestScreenShot.addTestFailurePNG(this.testname);
            ExtentTestManager.getTest().log(Status.FAIL, this.testname + " Failed");
        }
    }

    //Alternate Method
    void testing_MyTest000_Check_Product_Price(String ExpectedProductPriceData)
    {
        try
        {
            this.driver = new PrintedDress(this.driver).CheckTheProductPrice(ExpectedProductPriceData);
        }
        catch(Exception e)
        {
            ExtentTestManager.getTest().fail("Expected Product Price does not Match Product Price");
            new CreateFileStampForFailedTest().MyFileStampSetter(testname);
            CreateFailedImage.CreateNewScreenShot(this.driver, this.testname);
            AppendFailedTestScreenShot.addTestFailurePNG(this.testname);
            ExtentTestManager.getTest().log(Status.FAIL, this.testname + " Failed");
        }
    }

    void testing_MyTest000_Click_On_Printed_Chiffon_Dress()
    {
        try
        {
            this.driver = new PrintedDress(this.driver).ClickOnPrintedChiffonDress();
        }
        catch(Exception e)
        {

        }
    }

    void testing_MyTest000_Check_Printed_Chiffon_Dress_Price(String PrintedChiffonDressPrice)
    {
        try
        {
            this.driver = new PrintedDress(this.driver).CheckPrintedChiffonDressPrice(PrintedChiffonDressPrice);
            ExtentTestManager.getTest().pass("***---Passed---***");
            String ScreenShotName = testname + "PricePassedTest";
            new CreateFileStampForFailedTest().MyFileStampSetter(ScreenShotName);
            CreateFailedImage.CreateNewScreenShot(this.driver, ScreenShotName);
            //AppendFailedTestScreenShot.addTestFailurePNG(ScreenShotName);
            AppendPassedTestScreenShot.addTestPassPNG(ScreenShotName);
            ExtentTestManager.getTest().log(Status.PASS, ScreenShotName + " Passed");

        }
        catch(Exception e)
        {

        }
    }


    @Test(groups = "chrome test", priority = 0, dataProvider = "test000-data-provider")
    void MyTest000_Printed_Chiffon_Dress(String myTest, String myTestProdPrice)
    {
        this.testing_MyTest000_Navigate_To_HomePage();
        ExtentTestManager.getTest().pass("Navigated to Home Page");
        this.testing_MyTest000_Click_On_BestSellers();
        ExtentTestManager.getTest().pass("Clicked On Best Sellers");
        this.testing_MyTest000_GoTo_PrintedChiffonDress();
        ExtentTestManager.getTest().pass("Navigated to Printed Chiffon Dress");
        this.testing_MyTest000_ClickOn_EyeIcon();
        ExtentTestManager.getTest().pass("Clicked on Eye Icon");
        this.testing_MyTest000_Check_Displayed_Price(myTestProdPrice);
        this.testing_MyTest000_Check_Product_Price(myTestProdPrice);
        this.testing_MyTest000_Click_On_Printed_Chiffon_Dress();
        //this.testing_MyTest000_Check_Displayed_Price(myTestProdPrice);
        this.testing_MyTest000_Check_Printed_Chiffon_Dress_Price(myTestProdPrice);
    }


    //@AfterClass()
    @AfterTest
    void myAfterClass()
    {
        //this.driver.close();
        this.driver.quit();
        //extent.endTest(this.test);
        //this.extent.flush();
        //this.extent.close();
    }
}
