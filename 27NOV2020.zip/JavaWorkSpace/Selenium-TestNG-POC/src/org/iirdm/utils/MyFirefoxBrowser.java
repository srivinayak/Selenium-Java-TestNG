package org.iirdm.utils;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

public class MyFirefoxBrowser {

    public WebDriver SetFirefoxBrowser()
    {
        FirefoxOptions options = new FirefoxOptions();
        options.setAcceptInsecureCerts(true);
        WebDriver driver = new FirefoxDriver(options);

        Dimension d = new Dimension(350,510);

        driver.manage().window().setSize(d);

        return driver;
    }
}
