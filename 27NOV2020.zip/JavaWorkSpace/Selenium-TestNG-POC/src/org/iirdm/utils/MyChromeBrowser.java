package org.iirdm.utils;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class MyChromeBrowser {

    public WebDriver SetChromeBrowser()
    {
        ChromeOptions options = new ChromeOptions();
        //options.setBinary(".\\chromedriver.exe");
        options.setAcceptInsecureCerts(true);
        //options.addArguments("--log-level=3");
        //options.addArguments("--silent");
        //options.addArguments("--remote-debugging-port=9222");
        //options.addArguments("--allowed-ips='10.14.0.2'");
        //System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
        //System.setProperty("webdriver.chrome.logfile", ".\\chromedriver.log");
        //System.setProperty("webdriver.chrome.verboseLogging", "true");

        WebDriver driver = new ChromeDriver(options);
        Dimension d = new Dimension(350, 510);
        driver.manage().window().setSize(d);
        //driver.manage().window().maximize();

        return driver;
    }
}
