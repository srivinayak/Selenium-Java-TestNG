package org.iirdm.utils;

import org.openqa.selenium.WebDriver;
import org.iirdm.utils.MyChromeBrowser;
import org.iirdm.utils.MyFirefoxBrowser;


public class MyBrowser {

    WebDriver driver = null;

    public WebDriver SetMyBrowser(String browser)
    {
        if((browser.toLowerCase()).contains("chrome"))
        {
            MyChromeBrowser chrome = new MyChromeBrowser();
            this.driver = chrome.SetChromeBrowser();
        }
        else if((browser.toLowerCase()).contains("firefox"))
        {
            MyFirefoxBrowser firefox = new MyFirefoxBrowser();
            this.driver = firefox.SetFirefoxBrowser();
        }
        return this.driver;
    }

}
